import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { BrowserRouter,Route, Switch } from 'react-router-dom';
import Request from './components/Request';
import Register from './components/register';
import Login from './components/login';
import userbiddashboard from './userdashboard/button-redux/src/App';
import hotelbiddashboard from './hoteldashboard/src/App';
import HomeRequest from "./components/HomeRequest";
import HotelRequest from "./components/HotelFrontPage"
import HotelRegister from "./components/hotelregister"
ReactDOM.render(
  <BrowserRouter>
  <Switch>
    <Route path="/hotelregister" component={HotelRegister}/>
    <Route path="/hotelhome" component={HotelRequest}/>
    <Route path="/userhome" component={HomeRequest}/>
    <Route path="/request" component={Request}/>
    <Route path="/register" component={Register}/>
    <Route path="/userdashboard" component={userbiddashboard}/>
    <Route path="/HotelbidDashboard" component={hotelbiddashboard}/>
    <Route path="/login" component={Login}/>
    <Route path="/" component={App} />  
  </Switch>
  </BrowserRouter>  ,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();

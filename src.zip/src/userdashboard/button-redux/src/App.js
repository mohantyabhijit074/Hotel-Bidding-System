import React from 'react';
import {Provider} from 'react-redux'
import store from './components/redux/store'
import ButtonContainer from './components/ButtonContainer'
import './App.css';
import { HotelDetails } from './components/HotelDetails.js'
import { Route, BrowserRouter as Router } from 'react-router-dom';

import { Navbar, NavbarBrand } from 'react-bootstrap'

function App() {
  return (
    <Provider store = {store}>
      <div>
            <Navbar color="light" light expand="md">
              <NavbarBrand href="#">home</NavbarBrand>
                <NavbarBrand>user Dashboard</NavbarBrand>
              <NavbarBrand href="/">user bidding Dashboard</NavbarBrand>
            </Navbar>
      </div>

      <Router>
        <div className="App">
        <ButtonContainer />
        </div>
        <Route exact path = "/HotelDetails" component={HotelDetails} />
        </Router> 
    </Provider>
    
  );
}

export default App;

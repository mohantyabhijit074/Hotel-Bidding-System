export const LEVEL1 = 'LEVEL1'  // displays buttons like 5 star, 4 star etc..
export const LEVEL2 = 'LEVEL2'  // displays buttons like business, resort, etc..
export const LEVEL3 = 'LEVEL3'  // displays only one button "back" along with the appropriate data in the table



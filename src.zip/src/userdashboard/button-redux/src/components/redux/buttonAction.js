import {LEVEL1, LEVEL2, LEVEL3} from './buttonTypes'

export const setLevel1 = () => {
    return {
        type: LEVEL1
    }
}

export const setLevel2 = (status) => {
    return {
        type: LEVEL2,
        payload: status // status is used to determine which json file to choose to convert to table format in level 3
    }
}

export const setLevel3 = (param) => {
    return {
        type: LEVEL3,
        payload: param  // param is same as status
    }
}


#pending navbar for user bid dashboard

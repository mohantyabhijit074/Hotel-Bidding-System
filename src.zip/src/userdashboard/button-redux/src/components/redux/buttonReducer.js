import {LEVEL1, LEVEL2, LEVEL3} from './buttonTypes'

//import five_star_business from '../../json_files/5star_business.json'
import four_star_business from '../../json_files/four_star_business.json'
import all_hotels from '../../json_files/all_hotels.json'
import five_star_resort from '../../json_files/five_star_resort.json'
import four_star_resort from '../../json_files/four_star_resort.json'
import overall_lowest from '../../json_files/overall_lowest.json'

const initalState = {
    level: 1,
    status: "",
    data: all_hotels
}

// temporary function to demonstrate where sql filtering commands will be located
function filterFunction(data) {
    // TODO: add sql commands inplace of the loop below
    var temp=[]
        for(var i=0; i<data.length; i++) {
            if (data[i].type === "business" && data[i].category == "5 star") {
                temp.push({"category": data[i].category, "type": data[i].type,
                           "name": data[i].name, "price": data[i].price, "id": data[i].id,
                            "requirement_rating": data[i].requirement_rating })
            }
        }
    return temp;
}

const buttonReducer = (state = initalState, action) => {
    switch(action.type) {
        case LEVEL1:
            return {
                ...state,
                level: 1,
                status: "",
                data: all_hotels
            }
        case LEVEL2:
            return {
                ...state,
                level: 2,
                status: action.payload,
                data: all_hotels
            }
        case LEVEL3: {
            switch(action.payload) {
                case "five_star_business":
                    var data = filterFunction(all_hotels)
                    return {
                        ...state,
                        level: 3,
                        status: action.payload,
                        data: data
                    }
                case "four_star_business":
                    return {
                        ...state,
                        level: 3,
                        status: action.payload,
                        data: four_star_business
                    }
                case "five_star_resort":
                    return {
                        ...state,
                        level: 3,
                        status: action.payload,
                        data: five_star_resort
                    }
                case "four_star_resort":
                    return {
                        ...state,
                        level: 3,
                        status: action.payload,
                        data: four_star_resort
                    }
                case "overall":
                    return {
                        ...state,
                        level: 3,
                        status: action.payload,
                        data: overall_lowest
                    }
                default:
                    return {
                        ...state,
                        level: 3,
                        status: 'ERROR LOADING JSON FILE',
                        data: {}
                    }
            }
        }
        default: 
            return state 
    }
}

export default buttonReducer
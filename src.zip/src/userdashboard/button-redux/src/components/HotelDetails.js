import React, {useEffect, useState} from 'react'
import {Link} from 'react-router-dom'

export function HotelDetails(props) {
    const [hotel_name, set_hotel_name] = useState("")

    // equivalent to componentDidMount
    useEffect(
        () => {set_hotel_name(props.location.hotel_name)}
    )

    return (
        <div>
            <p><h1>Hotel name = {hotel_name}</h1></p>
            <textarea placeholder="queries?"></textarea>
            <button type="submit">submit query</button>
            <switch>
                <Link to="/"><button type="submit" onClick={() => alert("booking confirmed!")}>confirm booking</button></Link>
            </switch>
        <switch>
            <Link to="/"><button>back</button></Link>
        </switch>
        </div>
    )
}

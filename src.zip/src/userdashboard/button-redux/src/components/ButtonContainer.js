import React from 'react'
import { connect } from 'react-redux'
import { setLevel1, setLevel2, setLevel3 } from './redux/buttonAction'

import { Link } from 'react-router-dom'

import Button from 'react-bootstrap/Button'
import { Table } from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';

function ButtonContainer(props) {
    var status = ""

    // function to help display the filter buttons
    const buttonsHelper = () => {
        if (props.level === 1) {
            status = ""
            return (
                <div>
                    <Button variant="dark" onClick={() => {status = "five_star"; props.setLevel2(status)}}>5 star</Button>
                    <Button variant="dark" onClick={() => {status  = "four_star"; props.setLevel2(status)}}>4 star</Button>
                    <Button variant="danger" onClick={() => {status = "overall"; props.setLevel3(status)}}>find overall lowest bid</Button>
                </div>
            )
        }
        if (props.level === 2) {
            return (
                <div>
                    <Button onClick={() => {status = props.status+"_business"; props.setLevel3(status)}}>business</Button>
                    <Button onClick={() => {status = props.status+"_resort"; props.setLevel3(status)}}>resort</Button>
                    <Button onClick={props.setLevel1}>back</Button>
                </div>
            )
        }
        if (props.level === 3) {
            return (
                <div>
                    <Button onClick={props.setLevel1}>back</Button>
                </div>
            )
        }
    }

    // function to display the json data in a table format
    const table_rows = () => {
        var arr=[]
        for (var i=0; i<props.data.length; i++) {
            arr.push(
                <tr>
                    <td>{props.data[i].id}</td>
                    <td>{props.data[i].category}</td>
                    <td>{props.data[i].type}</td>
                    <td>
                        <Link to={{
                        pathname: '/HotelDetails',
                        hotel_name: props.data[i].name
                    }}>{props.data[i].name}</Link>
                    </td>
                    <td>{props.data[i].price}</td>
                    <td>{props.data[i].requirement_rating}</td>
                </tr>
            )
        }
        return arr 
    }

    return (
        <div>
            <h4>USER BID DASHBOARD</h4>
            { buttonsHelper() }
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>id</th>
                        <th>category</th>
                        <th>type</th>
                        <th>name</th>
                        <th>price</th>
                        <th>requirement_rating</th>
                    </tr>
                </thead>
                <tbody>
                    { table_rows() } 
                </tbody>
            </Table>
           
        </div>
    )
}

const mapStateToProps = state => {
    return {
        level: state.level,
        status: state.status,
        data: state.data 
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setLevel1: () => dispatch(setLevel1()),
        setLevel2: (param) => dispatch(setLevel2(param)),
        setLevel3: (param) => dispatch(setLevel3(param))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ButtonContainer)
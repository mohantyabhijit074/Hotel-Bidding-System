import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Provider} from 'react-redux'
import Container from './Components/Container'
import Store from './Components/redux/Store'
import { UserDetails } from './Components/UserDetails';
import {Route,BrowserRouter as Router} from 'react-router-dom'

function App() {
  return (
      <Provider store={Store}>
      <Router>
      <div className="App">
       <Container/>
       </div>
       <Route exact path="/UserDetails" component={UserDetails}/>
       </Router>
       
       </Provider>
       
  );
}

export default App;

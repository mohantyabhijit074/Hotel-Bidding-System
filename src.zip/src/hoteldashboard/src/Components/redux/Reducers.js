import {RETRACT,UPDATE} from './ActionTypes'
import users from './users.json' 
import Container from '../Container'

const initialState={
    data:users,
    count:Object.keys(users).length
}


const Reducers=(state=initialState,action)=>{
let newvalue=state.data
  if(action.type==='RETRACT'){
    let newUsers=state.data.filter(user =>{
        return action.id !== user.id
    });
    return {
        ...state,
        data:newUsers
    }}
   
    else if (action.type==='UPDATE'){
        
        console.log(action.value)
        let userIndex=newvalue.findIndex(user => user.id===action.id)
        console.log(userIndex)
        newvalue[userIndex].bidprice=action.value
        // var update=document.getElementById({userIndex})
        // console.log(this.props.data[action.id].id)
        var update=document.getElementById(users[action.id-1].username)
        console.log(update)
        update.value=action.value
        // console.log(update)
        // update.value=action.value

    return {
        ...state,
        data:newvalue
    }}
    else if(action.type==='UPDATE_COUNT')
    {
        return{
        ...state,
        count:state.count-1
        }

    }
    return state;
  }
 

export default Reducers
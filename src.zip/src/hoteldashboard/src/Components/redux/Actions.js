import {RETRACT} from './ActionTypes'
import {UPDATE} from './ActionTypes'
import users from './users.json'

export const retract=(users,index)=>{
    return{
        type:RETRACT,
        index
    }
}

export const update=(users,index)=>{
    return{
        type:UPDATE,
        index
    }
}
// function deleteRow(e)
// {
//   e.target.parentNode.parentNode.parentNode.remove();
// //   count=count-1;
  
// }
import {createStore} from 'redux'
import Reducers from './Reducers'
const Store=createStore(Reducers)
export default Store
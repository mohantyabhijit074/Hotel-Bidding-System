import React from 'react'
import {connect} from 'react-redux'
import Style from './redux/Style.css'
// import {Link} from 'react-router-dom'
// import Button from 'react-bootstrap/Button'
// import {Table} from 'react-bootstrap'
// import 'bootstrap/dist/css/bootstrap.min.css'
// import {RETRACT} from './redux/ActionTypes'
import users from './redux/users.json'
import * as ReactBootstrap from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.css'
import {retract} from './redux/Actions'
import Reducer from './redux/Reducers'
import {
  Navbar, NavbarBrand
} from 'reactstrap';

    const renderUser=(users,index,props)=>{
      console.log(props)
        return(
          <div>

          <tr key={index} className="table_data">
            <td> {users.username}</td>
            <td><textarea  className="textbox">{users.bidprice}</textarea></td>
            <td>{users.confo_date}</td>
            <td ><button>retract</button></td>
          </tr>
          
        
          </div>
        )
        
        }
    let count=Object.keys(users).length;
  
    function Container(){

        return(
            
            <div>
              <Navbar color="light" light expand="md">
              <NavbarBrand href="#">Home</NavbarBrand>
                <NavbarBrand>Hotel Dashboard</NavbarBrand>
              <NavbarBrand href="/">Hotel bidding Dashboard</NavbarBrand>
            </Navbar>
                <h1 className="head">Hotel Bidding Dashboard</h1>
                <div className="box">
                    <p id="info1">BIDDINGS</p>
                     {count}
                </div>
                <div className="table_headers">
                  <strong className="username">Username</strong>
                  <strong className="bidprice">Bidprice</strong>
                  <strong className="confodate">Confodate</strong>

                </div>
        
        <table>    
        <div className="table_div">
       
          {/* <tr className="table_head">
              <th> Username</th>
              <th> Bidprice</th>
              <th> Confodate</th>
        </tr> */}
          <tbody className="table_body">
          
            {users.map(renderUser)}
          </tbody> 
       
        </div>
        </table>   
                
                
        </div>
            
        )

    }

 const mapStateToProps=(state)=>{
   return{
    data:state.data
   }
 }
 /*
 const mapDispatchToProps = dispatch=>{
   return{
       //retract:(users,index)=>dispatch(retract(users,index))
       deleteIten:(id) =>{dispatch({type:'DELETE_ITEM',id:id})}
   }
 }
 
   */
       

 export default (mapStateToProps) (Container)
//export default Container
  

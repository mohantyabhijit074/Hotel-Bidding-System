import React from 'react'
import {connect} from 'react-redux'
import Style from './redux/Style.css'
import {Link} from 'react-router-dom'
import UserDetails from './UserDetails'
// import Button from 'react-bootstrap/Button'
// import {Table} from 'react-bootstrap'
// import 'bootstrap/dist/css/bootstrap.min.css'
import {RETRACT} from './redux/ActionTypes'
import users from './redux/users.json'
import * as ReactBootstrap from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.css'
import {retract} from './redux/Actions'
import Reducer from './redux/Reducers'
import {
  Navbar, NavbarBrand
} from 'reactstrap';

  const renderUser=(users,index,props)=>{
      console.log(props)
        return(
          <div>

          <tr key={index} className="table_data">
            <td> {users.username}</td>
            <td><textarea  className="textbox">{users.bidprice}</textarea></td>
            <td>{users.confo_date}</td>
            <td ><button>retract</button></td>
          </tr>
          
        
          </div>
        )
        
        }
      
    // let count=Object.keys(users).length;
    
  
    class Container extends React.Component{
      handleChange = (id) =>{
        this.props.deleteItem(id)
        this.props.updateCount()
      }
      handleUpdate = (id,value) =>{
        var value=document.getElementById(id).value
        this.props.updateItem(id,value)
        // console.log(value)
      }
      render(){
        // console.log(this.props)
      const {users}=this.props.data;
      var count=this.props.count;
    //   console.log(count)
    
      var value
      
      const usersList =this.props.data.map(user=>{
        // var update=document.getElementById(this.props.data.id)
        // console.log(this.props.data[user.id].id)
        return(
        //   <div key={user.id}>

          <tr key={user.id} className="table_data">
            <td><switch><Link to={{pathname:'/UserDetails',username:user.username}}>{user.username}</Link></switch></td>
            <td><input className="textbox" id={user.username} value={user.bidprice}/></td>
            <td><textarea  className="textbox" id={user.id}>{value}</textarea></td>
            <td><button id={user.id} onClick={()=>this.handleUpdate(user.id,value)}>Update</button></td>
            <td>{user.confo_date}</td>
            <td ><button onClick={()=>this.handleChange(user.id)}>retract</button></td>
          </tr>
          
        
          /* </div> */
        
        )
      })
     
           return(
          <div>
                <Navbar color="light" light expand="md">
              <NavbarBrand href="#">Home</NavbarBrand>
                <NavbarBrand>Hotel Dashboard</NavbarBrand>
              <NavbarBrand href="/">Hotel bidding Dashboard</NavbarBrand>
            </Navbar>
            <div className="box">
                    <p id="info1">BIDDINGS</p>
                     {count}
                </div>
            <h4 className="head">HOTEL BIDDING DASHBOARD</h4>
            <div className="table_div">
            <table className="table">
                <thead>
                    <tr>
                  <td>Username</td>
                  <td>Bidprice</td>
                  <td>Update price</td>
                  <td>Update</td>
                 <td>Confodate</td> 
                 <td>retract</td>
                  </tr>
                 </thead> 
                <tbody>
                    {usersList}
                </tbody>
                </table>
                </div>
            
            {/*<div className="table_div">
            {usersList}
           </div>*/}
          </div>
           ) 
      }

    }

 const mapStateToProps=(state)=>{
   return{
    data:state.data,
    count: state.count
   }
 }
 
 const mapDispatchToProps = (dispatch)=>{
   return{
       //retract:(users,index)=>dispatch(retract(users,index))
        deleteItem: (id) => {dispatch({type:'RETRACT',id:id})},
        updateItem: (id,value) =>{dispatch({type:'UPDATE',id:id,value:value})},
        updateCount:()=>{dispatch({type:'UPDATE_COUNT'})}
   }
 }
 
   
       

 export default connect(mapStateToProps,mapDispatchToProps) (Container)
//export default Container 
  

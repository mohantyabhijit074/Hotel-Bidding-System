import React,{useEffect,useState} from 'react'
import {Link} from 'react-router-dom'
import Style from './redux/Style.css'


 export function UserDetails(props){
    const[username,set_user_name]=useState("")
    useEffect(
        ()=>{set_user_name(props.location.username)}
    )
    return(
        <div className="userReq">
            <p>username : {username}</p>
            <p><i>items to be displayed:</i></p>
            <pre>  -<i>  User Requirements: </i></pre>
            <pre>      -<i>no of rooms</i></pre>
            <pre>      -<i>budget</i></pre>
            <pre>      -<i>food requirments</i></pre>
            <pre>      -<i>etc</i></pre>
            <pre>  -<i>Bidprice(option to change bidprice)</i></pre>
            <pre>  -<i>Leading bidprice</i></pre>
            <pre>  -etc</pre>
            <switch className="close">
                <Link to="/" className="X">X</Link>
            </switch>
        </div>
    )
}

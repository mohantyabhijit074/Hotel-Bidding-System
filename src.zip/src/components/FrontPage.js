import React,{Component} from 'react';
import style from '../css/Style.css';
import * as ReactBootstrap from "react-bootstrap";
import {Link} from "react-router-dom";
import {
  Navbar, NavbarBrand
} from 'reactstrap';

class FrontPage extends Component {
  render()
  {
  return (
    <div className="App">
       <div>
            <Navbar color="light" light expand="md">
              <NavbarBrand href="/">Home</NavbarBrand>
                <NavbarBrand href='/'>About</NavbarBrand>
              <NavbarBrand href="#">Contact Us</NavbarBrand>
            </Navbar>
      <h1>Website Name</h1>
      
     
      </div>
      <div className="User">
        <h2 className="title">For Users</h2>
        <Link to={`/userhome`}>USERS</Link>
        <p className="tutorial">Don't know how to use? <a className="click" href="#">clickhere</a> for the tutorial</p>
      </div>
      <div className="Hotel">
        <h2 className="hotel_title">For Hotels</h2>
        <Link to={`/hotelhome`}>HOTEL</Link>
        <p className="tutorial_h"> Don't know how to use? <a href="#" className="click">clickhere</a> for the tutorial</p>
      </div>

    </div>
  );
}
}

export default FrontPage;

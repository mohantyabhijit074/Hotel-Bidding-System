from flask import Flask, redirect, request, session 
from flask_restful import Api
from users import User, UserList
from hotels import HotelList, Hotel
from requests import Request, RequestList

app=Flask(__name__)
api=Api(app)
app.secret_key = 'random string'


api.add_resource(User, '/users/<string:userId>')
api.add_resource(Hotel, '/hotels/<int:hotelId>')
# api.add_resource(UserList, '/users')
#api.add_resource(HotelList, '/hotels')
api.add_resource(Request, '/requests/<int:requestId>')
# api.add_resource(RequestList, '/requests')

@app.route("/users", methods=["POST", "GET"])
def users():
    if request.method == 'POST':
        obj = UserList()
        print("calling obj post methods")
        status = obj.post()
        return redirect("http://localhost:3000/userdashboard")
    else:
        obj = UserList()
        return obj.get()

@app.route("/hotels", methods=["POST", "GET"])
def hotels():
 if request.method == 'POST':
    obj = HotelList()
    status = obj.post()
    return redirect("http://localhost:3000/hotelbiddashboard")
 else:
    obj = HotelList()
    return obj.get()

@app.route("/requests", methods=["POST", "GET"])
def requests():
 if request.method == 'POST':
     obj = RequestList()
     status = obj.post()
     return redirect("http://localhost:3000/userdashboard")
 else:
     obj = RequestList()
     return obj.get()
       
#@app.route("/hotels/<string:hotelId>", methods=["GET", "PUT", "DELETE"])
#def hotels(hotelId):
#    if request.method == 'GET':
#        obj = Hotels()
#        status = obj.get(hotelId)
#        return status
#    elif request.method == 'PUT':
#        obj = Hotels()
#        status = obj.put(hotelId)
#        return status
#    elif request.method == 'DELETE':
#        obj = Hotels()
#        status = obj.delete(hotelId)
#        return status
#


# @app.route("/login", methods=["POST"])
# def login():
#     if request.method == 'POST':
#         username = request.form['username']
#         session['username'] = username
#         return redirect("http://localhost:3000/")

# @app.route("/logout", methods=['GET'])
# def logout():
#     if 'username' not in session:
#         return '<h1>user has not logged in</h1>'
#     else:
#         username = session['username']
#         session.pop('username', None)
#         return '<h1> ' + username + ' has logged out </h1>'
    

if __name__=="__main__":
    app.run(debug=True)

# updated --
added new table called 'requestsHotels' which stores all corresponding requests to respective hotels based on location given in requests



ALTER TABLE requestsHotels RENAME TO temp;
CREATE TABLE requestsHotels (requestId integer references requests(requestId), hotelId integer references hotelsl(id), bidprice integer,
            primary key (requestId, hotelId));

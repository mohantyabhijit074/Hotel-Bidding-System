import sqlite3
from flask_restful import Resource, reqparse, abort

class Hotel(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("name", required=True)
    parser.add_argument("email", required=True)
    parser.add_argument("phone", required=True)

    @classmethod
    def get_by_id(cls, hotelId):
        connection = sqlite3.connect("data.db")
        cursor = connection.cursor()
        query = "SELECT * FROM hotels WHERE id=?"
        result = cursor.execute(query,(hotelId,))
        row = result.fetchone()
        connection.close()
        if row:
            return{
                hotelId:{
                    "name": row[1],
                    "email": row[2],
                    "phone": row[3]
                }
            }

    @classmethod
    def find_by_hotelname(cls, hotelname):
        connection = sqlite3.connect("data.db")
        cursor = connection.cursor()
        query = "SELECT * FROM hotels WHERE name=?"
        result = cursor.execute(query,(hotelname,))
        row = result.fetchone()
        connection.close()

        if row:
            return 0
        else:
            return 1

    def get(self, hotelId):
        result = self.get_by_id(hotelId)
        if result:
            return result
        return {"message":"hotel not found"}
        

    def delete(self,hotelId):
        connection = sqlite3.connect("data.db")
        cursor = connection.cursor()
        query = "DELETE FROM hotels WHERE id=?"
        cursor.execute(query,(hotelId,))
        connection.commit()
        connection.close()
        return {"message":"hotel with id {} is deleted succesfully".format(hotelId)}



    @classmethod
    def insert(cls, hotel):
        connection = sqlite3.connect("data.db")
        cursor = connection.cursor()
        query = "INSERT INTO hotels VALUES(?,?,?)"
        cursor.execute(query,(hotel["name"], hotel["email"], hotel["phone"]))
        connection.commit()
        connection.close()
        return hotel, 201

    @classmethod
    def update(cls, hotel):
        connection = sqlite3.connect("data.db")
        cursor = connection.cursor()
        query = "UPDATE hotels SET name=?,email=?, phone=? WHERE id=?"
        cursor.execute(query,(hotel["name"], hotel["email"], hotel["phone"], hotel["id"]))
        connection.commit()
        connection.close()
        return hotel, 201


    def put(self,hotelId):
        hotel = self.get_by_id(hotelId)
        data = Hotel.parser.parse_args()
        updated_hotel = {"id": hotelId, "name": data["name"], "email": data["email"], "phone": data["phone"]}
        if hotel is None:
            self.insert(updated_hotel)
        
        else:
            self.update(updated_hotel)
        
        return updated_hotel


class HotelList(Resource):
    def get(self):
        connection = sqlite3.connect("data.db")
        cursor = connection.cursor()
        query = "SELECT * FROM hotels"
        result = cursor.execute(query)
        hotels = []
        for row in result:
            hotels.append({row[0]:{"name": row[1], "email": row[2], "phone": row[3]}})

        return {"hotels": hotels}

    def post(self):
        #enable server connection
        connection=sqlite3.connect("data.db")
        cursor = connection.cursor()
        
        # enable parse args
        args = Hotel.parser.parse_args()

        if Hotel.find_by_hotelname(args['name']) == 0:
            abort(500, message="hotel admin already exists")
        
        # execute query
        name = args['name']

        query = "INSERT INTO hotels(name, email, phone) VALUES (?, ?, ?)"
        cursor.execute(query, (args['name'], args['email'], args['phone']))
        connection.commit()
        
        connection.close()
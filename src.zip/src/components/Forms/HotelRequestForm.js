import React from 'react';
import {Link} from 'react-router-dom';
import '../../css/homerequest.css';
import Background from '../../images/hotel2.jpg';
import 'react-day-picker/lib/style.css';
import 'react-dropdown/style.css';
import maps from '../../images/maps.jpg';
import {Field , reduxForm} from 'redux-form'
const InitialRequest = props => {
    const { handleSubmit,reset } = props
    return (
      <form onSubmit={handleSubmit}>
      <div>
        <nav className="navbar navbar-default">
          <div className="container-fluid">
          <div className="navbar-header">
              <Link to={`/`} className="navbar-brand">Home</Link>
          </div>
          <div className="navbar-header">
              <Link to={`/hotelregister`} className="navbar-brand">Register</Link>
          </div>
          <div className="navbar-header">
              <Link to={`/HotelbidDashboard`} className="navbar-brand">HotelbidDashboard</Link>
          </div>
          </div>
        </nav>
        <div className="main">
          <h1>WEBSITE NAME</h1>
          <div className="container">
              <img src={Background} alt="website logo"/>
            </div>
                <Link to={`/request`}><button className="btn">CONTINUE</button></Link>
        </div>
      </div>
      </form>
    )
  }

  export default reduxForm({
    form: 'simple' // a unique identifier for this form
  })(InitialRequest)


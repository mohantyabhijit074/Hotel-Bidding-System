import React from 'react';
import { Field, reduxForm } from 'redux-form'
import {Link} from 'react-router-dom'
import maps from '../../images/maps.jpg';
const RequestForm = props => {
    const { handleSubmit,reset } = props
    return (
      <form action="http://localhost:5000/requests" method="POST">
        <div>
        <div className="container">
              <h1>I want</h1>
          <div className="input1">
              <Field name='hall' component='select'>
                  <option value="banquethall">Banquet Hall</option>
                  <option value="conferencehall">Conference Hall</option>
                  <option value="seminarhall">Seminar Hall</option>
                  <option value="businnesshall">Buisness Hall</option>
              </Field>
          </div>
          <h3>In</h3>
          <div className='input2'>
              <div className='input21'>
                  <div>
                      <Field
                      name="state"
                      component="input"
                      type="text"
                      placeholder="STATE"
                      />
                  </div>
                  <div>
                      <Field
                      name="city"
                      component="input"
                      type="text"
                      placeholder="CITY"
                      />
                   </div>
                   <div>
                      <Field
                      name="locality"
                      component="input"
                      type="text"
                      placeholder="PREFERRED LOCALITY"
                      />
                  </div>
              </div>
              <div className="input22">
                  <img src={maps} alt="google maps"/>
              </div>
          </div>
          <h3>PREFERRED DATE</h3>
              <Field
              name="date"
              component="input"
              type="text"
              placeholder="DD-MM-YYYY"
              />
          </div>
          <label>For How many people you want to book</label>
          <div>
            <Field
              name="people"
              component="input"
              type="Number"
              placeholder="Number of People"
            />
          </div>
        </div>
        <div>
          <label>Food</label>
          <div>
            <label>
              <Field name="food" component="input" type="radio" value="Veg" />{' '}
              Veg
            </label>
            <label>
              <Field name="" component="input" type="radio" value="NonVeg" />{' '}
              Non Veg
            </label>
          </div>
        </div>
        <div>
          <label>Snacks Required</label>
          <div>
            <label>
              <Field name="snacks" component="input" type="radio" value="YES" />{' '}
              YES
            </label>
            <label>
              <Field name="" component="input" type="radio" value="NO" />{' '}
              No
            </label>
          </div>
        </div>
        <div>
          <label>How many rooms you want</label>
          <div>
            <Field
              name="rooms"
              component="input"
              type="Number"
              placeholder="Number of rooms"
            />
          </div>
        </div>
        <div>
          <label>Preferred Budget</label>
          <div>
            <Field
              name="budget"
              component="input"
              type="Number"
              placeholder="budget"
            />
          </div>
        </div>
        <div>
          <button type="submit">
            Submit
          </button>
          <button type="button" onClick={reset}>
            Clear Values
          </button>
        </div>
      </form>
    )
  }

  export default reduxForm({
    form: 'simple' // a unique identifier for this form
  })(RequestForm)
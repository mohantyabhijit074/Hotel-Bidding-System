import React from 'react'
import { Field, reduxForm } from 'redux-form'
import {Link} from 'react-router-dom';
const LoginForm = props => {
  const { handleSubmit, reset } = props
  return (
    <form onSubmit={handleSubmit}>
      <label>Username</label>
      <div>
        <Field
          name="username"
          component="input"
          type="text"
          placeholder="username"
        />
      </div>
      <div>
      <label>Password</label>
        <div>
          <Field
            name="password"
            component="input"
            type="password"
            placeholder="password"
          />
        </div>
      </div>
      <div>
      <div>
        <button type="submit" >
          Submit
        </button>
        <button type="button" onClick={reset}>
          Clear Values
        </button>
      <div>
        <Link to={`/register`}>If you don't have an account Click Here </Link>
      </div>
      </div>
      </div>
    </form>
  )
}

export default reduxForm({
  form: 'simple' // a unique identifier for this form
})(LoginForm)
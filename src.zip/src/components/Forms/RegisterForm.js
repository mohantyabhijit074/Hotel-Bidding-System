import React from 'react'
import { Field, reduxForm } from 'redux-form'
import {Link} from 'react-router-dom';
const RegisterForm = props => {
  const { handleSubmit, reset } = props
  return (
    <form action="http://localhost:5000/users" method="POST" >
      <div>
        <label>First Name</label>
        <div>
          <Field
            name="firstname"
            component="input"
            type="text"
            placeholder="First Name"
          />
        </div>
      </div>
      <div>
        <label>Last Name</label>
        <div>
          <Field
            name="lastname"
            component="input"
            type="text"
            placeholder="Last Name"
          />
        </div>
      </div>
      <div>
        <label>Email</label>
        <div>
          <Field
            name="email"
            component="input"
            type="email"
            placeholder="Email"
          />
        </div>
      </div>
      <label>Username</label>
      <div>
        <Field
          name="username"
          component="input"
          type="text"
          placeholder="username"
        />
      </div>
      <div>
      <label>Password</label>
        <div>
          <Field
            name="password"
            component="input"
            type="password"
            placeholder="password"
          />
        </div>
      </div>
      <div>
      <label>Confirm Password</label>
        <div>
          <Field
            name="cnfpassword"
            component="input"
            type="password"
            placeholder="confirm password"
          />
        </div>
      <div>
        <button type="submit" >
          Submit
        </button>
        <button type="button" onClick={reset}>
          Clear Values
        </button>
      <div>
        <Link to={`/login`}>If you already have an account click here</Link>
      </div>
      </div>
      </div>
    </form>
  )
}

export default reduxForm({
  form: 'simple' // a unique identifier for this form
})(RegisterForm)
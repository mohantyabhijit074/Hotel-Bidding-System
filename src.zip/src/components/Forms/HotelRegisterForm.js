import React from 'react'
import { Field, reduxForm } from 'redux-form'
import {Link} from 'react-router-dom';
const HotelRegisterForm = props => {
  const { handleSubmit, reset } = props
  return (
    <form action="http://localhost:5000/hotels" method="POST" >
      <div>
        <label>Hotel Name</label>
        <div>
          <Field
            name="name"
            component="input"
            type="text"
            placeholder="Hotel Name"
          />
        </div>
      </div>
      <div>
        <label>Email</label>
        <div>
          <Field
            name="email"
            component="input"
            type="text"
            placeholder="Email"
          />
        </div>
      <label>Phone number</label>
        <div>
          <Field
            name="phone"
            component="input"
            type="integer"
            placeholder="Phone Number"
          />
        </div>
      </div>
      <div>
      <div>
        <button type="submit" >
          Submit
        </button>
        <button type="button" onClick={reset}>
          Clear Values
        </button>
      <div>
        <Link to={`/login`}>If you already have an account click here</Link>
      </div>
      </div>
      </div>
    </form>
  )
}

export default reduxForm({
  form: 'simple' // a unique identifier for this form
})(HotelRegisterForm)
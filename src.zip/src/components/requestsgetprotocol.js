import Request from '../../../../components/api/requests.py'

requestsjson = Request.get()

alert(requestsjson)